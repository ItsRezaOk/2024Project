import React from 'react';

const Hero = () => {
  return (
    <section id="home" className="hero">
      <h2>Welcome to the ultimate snowboard finder</h2>
      <p>Get matched with the perfect board for your park, freestyle, or street riding style.</p>
      <a href="#find-board" className="cta-button">Start Now</a>
    </section>
  );
};

export default Hero;
