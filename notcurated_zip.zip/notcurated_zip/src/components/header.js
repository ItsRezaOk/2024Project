import React from 'react';

const Header = () => {
  return (
    <header>
      <h1>Find Your Perfect Park/Freestyle/Street Snowboard</h1>
      <nav>
        <ul>
          <li><a href="#home">Home</a></li>
          <li><a href="#find-board">Find Your Board</a></li>
          <li><a href="#reviews">Reviews</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
