import React, { useState } from 'react';

const SnowboardFinder = () => {
  const [result, setResult] = useState('');
  const handleSubmit = async (event) => {
    event.preventDefault();
    const response = await fetch('http://localhost:5000/find-board', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        type: event.target['riding-style'].value,
        experience: event.target['experience-level'].value,
        height: event.target['height'].value,
        weight: event.target['weight'].value
      })
    });
  
    const result = await response.json();
    setResult(`Your recommended snowboard is: ${result.name}`);
  };
  
  };

  return (
    <section id="find-board" className="finder">
      <h2>Find Your Snowboard</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="riding-style">Riding Style:</label>
        <select id="riding-style" name="riding-style">
          <option value="park">Park</option>
          <option value="street">Street</option>
          <option value="halfpipe">Halfpipe</option>
        </select>

        <label htmlFor="experience-level">Experience Level:</label>
        <select id="experience-level" name="experience-level">
          <option value="beginner">Beginner</option>
          <option value="intermediate">Intermediate</option>
          <option value="advanced">Advanced</option>
        </select>

        <label htmlFor="height">Your Height (cm):</label>
        <input type="number" id="height" name="height" required />

        <label htmlFor="weight">Your Weight (kg):</label>
        <input type="number" id="weight" name="weight" required />

        <button type="submit" className="cta-button">Find My Board</button>
      </form>

      {result && <div className="result"><h3>{result}</h3></div>}
    </section>
  );

export default SnowboardFinder;
