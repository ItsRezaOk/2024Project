import React from 'react';
import Header from './components/header';
import Hero from './components/hero';
import SnowboardFinder from './components/SnowboardFinder';
import Reviews from './components/Reviews';
import Contact from './components/contact';
import Footer from './components/footer';

function App() {
  return (
    <div className="App">
      <Header />
      <Hero />
      <SnowboardFinder />
      <Reviews />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;
