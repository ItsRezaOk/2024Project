const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

// Connect to MongoDB
mongoose.connect('YOUR_MONGODB_CONNECTION_STRING', { useNewUrlParser: true, useUnifiedTopology: true });

const snowboardSchema = new mongoose.Schema({
  name: String,
  type: String,
  experience: String,
  heightRange: String,
  weightRange: String
});

const Snowboard = mongoose.model('Snowboard', snowboardSchema);

// API routes
app.post('/find-board', async (req, res) => {
  const { type, experience, height, weight } = req.body;
  const board = await Snowboard.findOne({ type, experience });
  res.json(board);
});

app.listen(5000, () => console.log('Server running on port 5000'));
